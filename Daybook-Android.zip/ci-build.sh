#!/usr/bin/env bash
# Builds Daybook on GitHub: an APK to install directly and an AAB for the Play Store.
set -euo pipefail

# Bundle the app's fonts so it needs no internet connection.
FONTS=app/src/main/assets/www/fonts
mkdir -p "$FONTS"
get() { curl -fsSL --retry 3 "https://cdn.jsdelivr.net/npm/@fontsource/$1@5/files/$2" -o "$FONTS/$2" || echo "Could not download $2; the app will use the phone's font instead."; }
for w in 500 700 800; do get bricolage-grotesque bricolage-grotesque-latin-$w-normal.woff2; done
for w in 400 500 600 700; do get figtree figtree-latin-$w-normal.woff2; done
for w in 400 500; do get dm-mono dm-mono-latin-$w-normal.woff2; done

echo "sdk.dir=$ANDROID_HOME" > local.properties
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null || true

chmod +x gradlew
./gradlew assembleRelease bundleRelease --no-daemon --stacktrace

mkdir -p out
cp app/build/outputs/apk/release/app-release.apk out/Daybook.apk
cp app/build/outputs/bundle/release/app-release.aab out/Daybook-PlayStore.aab
ls -la out
