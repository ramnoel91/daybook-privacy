# Daybook Calendar for Android

Your Daybook calendar as an Android app, with real notifications:

- **Morning summary** every day at the time you pick in Settings (7am by default).
- **Event reminders** for any event with "Remind me" set.
- Both arrive even when Daybook is closed. The app keeps the next 14 days scheduled and refreshes that list every time you open it, so open Daybook at least once every two weeks.

## Option A: build it on GitHub (no software to install)

1. Sign in at github.com and create a new **private** repository named `daybook`. Leave it empty.
2. On the new repository page, choose **uploading an existing file**, then drag in everything inside this folder, including the hidden `.github` folder. (If your computer hides it, upload `.github/workflows/build.yml` on its own afterwards, keeping that folder path.)
3. Commit the files. GitHub starts building right away. Watch the **Actions** tab; it takes about 5 minutes.
4. Open the repository's **Releases** page on your phone, tap **Daybook.apk**, and install it.

Every later change you upload builds a new APK the same way.

## Option B: build it on your laptop

1. Install Android Studio from developer.android.com/studio.
2. Open Android Studio, choose **Open**, and pick this folder. Let it finish syncing (the first time downloads a few hundred MB).
3. Choose **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
4. The APK is in `app/build/outputs/apk/`. Copy it to your phone and tap it to install.

## Installing on your phone

- Android will ask to allow installs from your browser or file app. Allow it once.
- When Daybook first opens, allow notifications.
- To update later, install the new APK over the old one. Your events stay, because every build uses the same signing key (`app/daybook.keystore`).

## Moving your events from the web version

In the web version, open **Settings > Backup > Save backup**. In the app, open **Settings > Backup > Restore** and pick that file.

## Good to know

- Events are stored on the phone. Uninstalling the app erases them, so save a backup now and then.
- Three original wallpapers are built in. Add your own from your gallery in **Settings > Wallpapers**.
- The app needs no internet connection; its fonts are bundled during the GitHub build.
- Each GitHub build makes two files: `Daybook.apk` to install directly, and `Daybook-PlayStore.aab` to upload to Google Play.
