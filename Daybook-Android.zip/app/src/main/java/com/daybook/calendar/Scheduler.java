package com.daybook.calendar;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Keeps Android's alarm list in step with what the page asks for: the morning
 * summary for each of the next 14 days plus every event reminder in that window.
 */
public final class Scheduler {
    static final String CHANNEL_ID = "daybook";
    private static final String PREFS = "daybook";
    private static final String KEY_LIST = "schedule";
    private static final String KEY_COUNT = "count";
    private static final int BASE_CODE = 1000;
    private static final int MAX = 60;

    private Scheduler() {
    }

    static void ensureChannel(Context ctx) {
        NotificationManager nm = ctx.getSystemService(NotificationManager.class);
        if (nm == null || nm.getNotificationChannel(CHANNEL_ID) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Reminders and morning summary",
                NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Event reminders and your daily morning summary from Daybook");
        ch.enableVibration(true);
        nm.createNotificationChannel(ch);
    }

    /** Replace every scheduled Daybook alarm with the list in json. */
    static synchronized void apply(Context ctx, String json) {
        AlarmManager am = ctx.getSystemService(AlarmManager.class);
        if (am == null) return;
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        // cancel what we set last time
        int old = prefs.getInt(KEY_COUNT, MAX);
        for (int i = 0; i < Math.max(old, MAX); i++) {
            PendingIntent pi = pending(ctx, i, null, null, null, PendingIntent.FLAG_NO_CREATE);
            if (pi != null) {
                am.cancel(pi);
                pi.cancel();
            }
        }

        int count = 0;
        long now = System.currentTimeMillis();
        try {
            JSONArray list = new JSONArray(json == null ? "[]" : json);
            for (int i = 0; i < list.length() && count < MAX; i++) {
                JSONObject item = list.getJSONObject(i);
                long at = item.optLong("at", 0);
                if (at <= now) continue;
                PendingIntent pi = pending(ctx, count, item.optString("id", "d" + i),
                        item.optString("title", "Daybook"), item.optString("body", ""),
                        PendingIntent.FLAG_UPDATE_CURRENT);
                boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
                try {
                    if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                    else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                } catch (SecurityException e) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                }
                count++;
            }
        } catch (Exception ignored) {
        }
        prefs.edit().putString(KEY_LIST, json).putInt(KEY_COUNT, count).apply();
    }

    /** After a restart, put back whatever was scheduled before. */
    static void restore(Context ctx) {
        String json = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LIST, "[]");
        apply(ctx, json);
    }

    private static PendingIntent pending(Context ctx, int slot, String id, String title, String body, int flag) {
        Intent intent = new Intent(ctx, AlarmReceiver.class);
        intent.setAction("com.daybook.calendar.ALARM_" + slot);
        if (id != null) {
            intent.putExtra("id", id);
            intent.putExtra("title", title);
            intent.putExtra("body", body);
        }
        return PendingIntent.getBroadcast(ctx, BASE_CODE + slot, intent, flag | PendingIntent.FLAG_IMMUTABLE);
    }
}
