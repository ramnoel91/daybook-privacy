package com.daybook.calendar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Alarms are cleared when the phone restarts or the app updates, so set them again. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)
                || "android.intent.action.TIME_SET".equals(a) || Intent.ACTION_TIMEZONE_CHANGED.equals(a)) {
            Scheduler.restore(ctx);
        }
    }
}
